from flask import Flask, render_template, send_from_directory, request, jsonify, redirect, url_for
import os

app = Flask(__name__)

# The folder where this script is located
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Route to list all files except .py files and the templates folder
@app.route('/')
def index():
    files = [f for f in os.listdir(BASE_DIR)
             if os.path.isfile(os.path.join(BASE_DIR, f)) 
             and not f.endswith('.py') 
             and f != 'app.py' 
             and 'templates' not in f]
    return render_template('index.html', files=files)

# Route to download a file
@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(BASE_DIR, filename, as_attachment=True)

# Route to delete a file
@app.route('/delete/<filename>', methods=['POST'])
def delete_file(filename):
    try:
        os.remove(os.path.join(BASE_DIR, filename))
        return jsonify({'success': True, 'message': f'{filename} deleted successfully.'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

if __name__ == '__main__':
    app.run(debug=True)
